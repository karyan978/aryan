<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>DigitMarketing - Business Category Bootstrap Responsive Template | Services :: W3layouts</title>
    <!--/google-fonts -->
    <link href="//fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,700;1,400;1,600&display=swap" rel="stylesheet">
    <!--//google-fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--/Header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a class="navbar-brand pe-xl-5 pe-lg-4" href="index.php">
                        <span class="sublog">Digit</span>Marketing
                    </a></h1>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav me-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
<li class="nav-item">
                            <a class="nav-link active" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>

                    </ul>
                    <ul class="navbar-nav search-right mt-lg-0 mt-2">
                        <li class="nav-item" title="Search"><a href="#search" class="search-search">
                                <span class="fas fa-search" aria-hidden="true"></span></a></li>
                        <li class="nav-item me-lg-3"><a href="" class="phone-btn btn btn-primary btn-style d-none d-lg-block btn-style ms-2">Purchase</a></li>
                    </ul>

                    <!-- //toggle switch for light and dark theme -->

                    <!-- search popup -->
                    <div id="search" class="w3lpop-overlay">
                        <div class="w3lpopup">
                            <form action="#formsearch" method="GET" class="d-sm-flex">
                                <input class="form-control me-2" type="search" placeholder="Search here..." aria-label="Search" required="">
                                <button class="btn btn-style btn-primary" type="submit">Search</button>
                                <a class="close" href="#formsearch">&times;</a>
                            </form>
                        </div>
                    </div>
                    <!-- /search popup -->
                </div>
                <!-- toggle switch for light and dark theme -->
                <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!--//Header-->
    <!-- breadcrumb -->
    <section class="w3l-about-breadcrumb">
        <div class="breadcrumb-bg breadcrumb-bg-about">
            <div class="container py-lg-5 py-sm-4">
                <div class="w3breadcrumb-gids text-center">
                    <div class="w3breadcrumb-info mt-5">
                        <h2 class="w3ltop-title pt-4">Services</h2>
                        <ul class="breadcrumbs-custom-path">
                            <li><a href="index.php">Home</a></li>
                            <li class="active"><span class="fas fa-angle-double-right mx-2"></span> Services </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//breadcrumb-->
    <!--/services-->
    <section class="w3l-services2" id="services">
        <div id="cwp23-block" class="py-5">
            <div class="container py-lg-5">
                <div class="row cwp23-content mb-lg-5 mb-4">
                    <div class="col-lg-6 cwp23-img">
                        <h6 class="title-subhny mb-2">What We Do?</h6>
                        <h3 class="title-w3l mb-4">Advertise, analyze, and optimize! We do it all for you.
                        </h3>



                    </div>
                    <div class="col-lg-6 cwp23-text mt-lg-0 mt-5 ps-lg-5">
                        <p class="mb-4">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Cras varius lorem ac velit pharetra.Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet Morbi ac metus vitae diam scelerisque malesuada eget.

                        </p>
                        <p class="mb-4">Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                            Morbi ac metus vitae diam scelerisque malesuada eget eu mauris.Cras varius lorem ac velit pharetra.

                        </p>

                    </div>
                </div>
                <div class="row cwp23-content">
                    <div class="col-lg-6 cwp23-img">
                        <div class="w3l-market-seo-img">
                            <img src="assets/images/mac-business.png" alt="business" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-6 cwp23-text mt-lg-0 mt-5 ps-lg-5">
                        <h6 class="title-subhny mb-2">What We Offer</h6>
                        <h3 class="title-w3l mb-4">The digital marketing agency for growth
                        </h3>

                        <p class="mb-4">Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                            Morbi ac metus vitae diam scelerisque malesuada eget eu mauris.Cras varius lorem ac velit pharetra.

                        </p>
                        <div class="w3l-buttons mt-sm-5 mt-4">
                            <a class="btn btn-primary btn-style me-2" href="services.php">Read More </a>
                            <a class="btn btn-outline-primary btn-style mr-2" href="contact.php"> Contact Us </a>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!--//services-->
    <!-- features section -->
    <section class="w3l-features w3l-passion-mid-sec py-5" id="features">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="main-cont-wthree-2 align-items-center text-left">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-6">
                        <div class="grids-1 box-wrap">
                            <div class="icon">
                                <i class="fas fa-pencil-ruler"></i>
                            </div>
                            <h4><a href="#service" class="title-head mb-3">Creative Plan & Design</a></h4>
                            <p class="text-para">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mt-md-0 mt-5">
                        <div class="grids-1 box-wrap">
                            <div class="icon">
                                <i class="fas fa-toolbox"></i>
                            </div>
                            <h4><a href="#service" class="title-head mb-3">Best Professional Liability</a></h4>
                            <p class="text-para">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mt-lg-0 mt-5">
                        <div class="grids-1 box-wrap">
                            <div class="icon">
                                <i class="fas fa-tools"></i>
                            </div>
                            <h4><a href="#service" class="title-head mb-3">Technology Advisory
                                </a></h4>
                            <p class="text-para">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mt-md-0 mt-5">
                        <div class="grids-1 box-wrap">
                            <div class="icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <h4><a href="#service" class="title-head mb-3">Dedicated To Our Clients</a></h4>
                            <p class="text-para">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--//features section -->

    <!--/w3l-services-->
    <section class="w3l-services py-5" id="services">
        <div class="container py-md-5 py-3 pb-4">
            <div class="title-content mb-5 text-center">
                <h6 class="title-subhny mb-2">Services</h6>
                <h3 class="title-w3l mb-4">We Offer Services</h3>
            </div>
            <div class="row about-cols">
                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="fas fa-envelope-open-text"></i></div>

                        <h4 class="title"><a href="#">Email Marketing</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="fas fa-search-dollar"></i></div>

                        <h4 class="title"><a href="#">Market Research</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="fas fa-chalkboard-teacher"></i></div>
                        <h4 class="title"><a href="#">Online Marketing</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="far fa-edit"></i></div>

                        <h4 class="title"><a href="#">Web Development</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="fas fa-key"></i></div>

                        <h4 class="title"><a href="#">Keyword Research</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mt-md-0 mt-3">
                    <div class="about-col">
                        <div class="icon"><i class="fas fa-sitemap"></i></div>
                        <h4 class="title"><a href="#">Optimization</a></h4>
                        <p>
                            Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//w3l-services-->

    <!-- footer -->
    <section class="w3l-footer-29-main">
        <div class="footer-29 py-5">
            <div class="container py-lg-4">
                <div class="row footer-top-29">
                    <div class="col-lg-4 col-md-6 footer-list-29 footer-1 pe-lg-5">
                        <div class="footer-logo mb-4">
                            <h2><a class="navbar-brand" href="index.php">
                                    <span class="sublog">Digit</span>Marketing
                                </a></h2>
                        </div>
                        <p>Lorem ipsum dolor sit, amet consectetur elit.Pellen tesque libero ut justo, ultrices in ligula accusantium libero fugit.

                        </p>
                        <div class="w3l-two-buttons mt-4">
                            <a href="#trail" class="btn btn-primary btn-style"> Try it For Free </a>
                        </div>
                        <div class="main-social-footer-29 mt-5">
                            <a href="#facebook" class="facebook"><span class="fab fa-facebook-f"></span></a>
                            <a href="#twitter" class="twitter"><span class="fab fa-twitter"></span></a>
                            <a href="#instagram" class="instagram"><span class="fab fa-instagram"></span></a>
                            <a href="#linkedin" class="linkedin"><span class="fab fa-linkedin-in"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-2 mt-sm-0 mt-5">

                        <ul>
                            <h6 class="footer-title-29">Links</h6>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="contact.php">Contact us</a></li>

                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-3 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Services</h6>
                        <ul>
                            <li><a href="#traning">Web Design</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#traning">Marketing Plans</a></li>
                            <li><a href="#marketplace">Digital Services</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#platform">Product Selling</a></li>
                        </ul>

                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">More Info</h6>
                        <ul>
                            <li><a href="#seo">Offline SEO</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#hack">Growth Hacking</a></li>
                            <li><a href="#studio">Film Studio</a></li>
                            <li><a href="#branding">Branding</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#marketplace">Lead Generation</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Support</h6>
                        <ul>
                            <li><a href="#awards">Awards</a></li>
                            <li><a href="#secutiry">Security</a></li>

                            <li><a href="#proj">Products</a></li>
                            <li><a href="#efaq">faQ</a></li>
                            <li><a href="#help">Help</a></li>
                            <li><a href="#mail">Mail Us</a></li>
                            <li><a href="#terms">Terms
                                </a></li>
                            <li><a href="#policy">Privacy Policy</a></li>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- copyright -->
        <section class="w3l-copyright text-center">
            <div class="container">
                <p class="copy-footer-29">© 2021 DigitMarketing. All rights reserved. Design by <a href="https://w3layouts.com/" target="_blank">
                        W3Layouts</a></p>
            </div>

            <!-- move top -->
            <button onclick="topFunction()" id="movetop" title="Go to top">
                <span class="fas fa-arrow-up"></span>
            </button>
            <script>
                // When the user scrolls down 20px from the top of the document, show the button
                window.onscroll = function() {
                    scrollFunction()
                };

                function scrollFunction() {
                    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                        document.getElementById("movetop").style.display = "block";
                    } else {
                        document.getElementById("movetop").style.display = "none";
                    }
                }

                // When the user clicks on the button, scroll to the top of the document
                function topFunction() {
                    document.body.scrollTop = 0;
                    document.documentElement.scrollTop = 0;
                }

            </script>
            <!-- /move top -->
        </section>
        <!-- //copyright -->
    </section>
    <!-- //footer -->
    <!-- Js scripts -->
    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/theme-change.js"></script>
    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- //bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
