<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>DigitMarketing - Business Category Bootstrap Responsive Template | Home :: W3layouts</title>
    <!--/google-fonts -->
    <link href="//fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,700;1,400;1,600&display=swap" rel="stylesheet">
    <!--//google-fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--/Header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a class="navbar-brand pe-xl-5 pe-lg-4" href="index.php">
                        <span class="sublog">Digit</span>Marketing
                    </a></h1>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav me-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
						<li class="nav-item">
                            <a class="nav-link" href="services..php">Services</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>

                    </ul>
                    <ul class="navbar-nav search-right mt-lg-0 mt-2">
                        <li class="nav-item" title="Search"><a href="#search" class="search-search">
                                <span class="fas fa-search" aria-hidden="true"></span></a></li>
                        <li class="nav-item me-lg-3"><a href="" class="phone-btn btn btn-primary btn-style d-none d-lg-block btn-style ms-2">Purchase</a></li>
                    </ul>

                    <!-- //toggle switch for light and dark theme -->

                    <!-- search popup -->
                    <div id="search" class="w3lpop-overlay">
                        <div class="w3lpopup">
                            <form action="#formsearch" method="GET" class="d-sm-flex">
                                <input class="form-control me-2" type="search" placeholder="Search here..." aria-label="Search" required="">
                                <button class="btn btn-style btn-primary" type="submit">Search</button>
                                <a class="close" href="#formsearch">&times;</a>
                            </form>
                        </div>
                    </div>
                    <!-- /search popup -->
                </div>
                <!-- toggle switch for light and dark theme -->
                <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!--//Header-->
    <!-- main-slider -->
    <section class="w3l-main-content" id="home">
        <div class="container">
            <div class="row align-items-center w3l-slider-grids">
                <div class="col-lg-6 w3l-slider-left-info pe-lg-5">
                    <h6 class="title-subhny mb-2">We are gathered</h6>
                    <h3 class="mb-2 title"> <span>For</span> Your </h3>
                    <h3 class="mb-4 title">Website Design</h3>
                    <p class="w3banr-p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident, excepturi.
                        Distinctio accusantium fugit odit fugit ipsam.</p>
                    <div class="w3l-buttons mt-sm-5 mt-4">
                        <a class="btn btn-primary btn-style me-2" href="about.php">Read More </a>
                        <a class="btn btn-outline-primary btn-style " href="contact.php"> Get Started </a>
                    </div>
                </div>
                <div class="col-lg-6 w3l-slider-right-info mt-lg-0 mt-5 ps-lg-5 align-items-center">
                    <div class="w3l-main-slider banner-slider">

                                <div class="slider-info">
                                    <div class="w3l-slidehny-img banner-top1">
                                        <img src="assets/images/banner1.jpg" alt="" class="radius-image img-fluid">
                                    </div>
                                </div>
                            
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /main-slider -->
    <section class="w3l-grids-3 py-5">
        <div class="container py-md-5 py-3">
            <div class="row align-items-center">
                <div class="col-lg-6 header-sec">
                    <h6 class="title-subhny mb-2">Design & Marketing</h6>
                    <h3 class="title-w3l">
                        Let's grow your business together.
                    </h3>
                </div>
                <div class="col-lg-6 header-sec-paraw3 ps-lg-4">
                    <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                        ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet
                        elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit amet.</p>
                </div>
            </div>
            <div class="row bottom_grids text-left mt-lg-5 align-items-center">
                <div class="col-lg-4 col-md-6 mt-5">
                    <div class="grid-block">
                        <a href="#grids" class="d-block">
                            <div class="grid-block-infw3">
                                <div class="grid-block-icon"><span class="fas fa-user-shield"></span></div>
                                <h4 class="my-3">Great Support.</h4>
                            </div>
                            <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-5">
                    <div class="grid-block active">
                        <a href="#grids" class="d-block">
                            <div class="grid-block-infw3">
                                <div class="grid-block-icon"><span class="far fa-edit"></span></div>
                                <h4 class="my-3">Perfect Design.</h4>
                            </div>
                            <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mt-5">
                    <div class="grid-block">
                        <a href="#grids" class="d-block">
                            <div class="grid-block-infw3">
                                <div class="grid-block-icon"><span class="fas fa-signal" aria-hidden="true"></span></div>

                                <h4 class="my-3">
                                    SEO Optimized.</h4>
                            </div>
                            <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//grids-->
    <!--/circles-section-->
    <section class="w3l-circles-sec" id="circle">
        <div class="midd-w3 py-5">
            <div class="container py-lg-5 py-3">
                <!--/row-2-->
                <div class="w3l-circles">
                    <div class="w3l-circles-infhny">
                        <div class="title-content text-left">
                            <h6 class="title-subhny mb-2">Open the future</h6>
                            <h3 class="title-w3l two">Innovative Design & Branding

                            </h3>
                        </div>
                        <p class="mt-md-4 mt-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                            ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet
                            elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit amet. </p>
                    
                    </div>
                </div>
                <!--//row-2-->

            </div>
        </div>
    </section>
    <!--//circles-section-->
    <!--/img-grids-->
    <section class="w3l-img-grids" id="gridsimg">
        <div class="blog py-5" id="classes">
            <div class="container py-lg-5">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-6 item mt-lg-0 mt-5">
                        <div class="w3img-grids-info">
                            <div class="w3img-grids-info-gd position-relative">
                                <a href="#services">
                                    <div class="page">
                                        <div class="photobox photobox_triangular photobox_scale-rotated">
                                            <div class="photobox__previewbox media-placeholder">
                                                <img class="img-fluid photobox__preview media-placeholder__media radius-image" src="assets/images/g1.jpg" alt="">
                                            </div>
                                            <div class="photobox__info-wrapper">
                                                <div class="photobox__info"><span>Responsive</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div class="w3img-grids-info-gd-content mt-4">
                                    <a href="#gridsimg" class="titile-img d-block">
                                        <h4 class="mb-2">
                                            Research.</h4>
                                    </a>
                                    <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>

                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item mt-lg-0 mt-5">
                        <div class="w3img-grids-info">
                            <div class="w3img-grids-info-gd position-relative">
                                <a href="#services">
                                    <div class="page">

                                        <div class="photobox photobox_triangular photobox_scale-rotated">
                                            <div class="photobox__previewbox media-placeholder">
                                                <img class="img-fluid photobox__preview media-placeholder__media radius-image" src="assets/images/g2.jpg" alt="">
                                            </div>
                                            <div class="photobox__info-wrapper">
                                                <div class="photobox__info"><span>Unlimited </span></div>
                                            </div>
                                        </div>

                                    </div>
                                </a>
                                <div class="w3img-grids-info-gd-content mt-4">
                                    <a href="#gridsimg" class="titile-img d-block">
                                        <h4 class="mb-2">
                                            Presentation.</h4>
                                    </a>
                                    <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>

                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item mt-lg-0 mt-5">
                        <div class="w3img-grids-info">
                            <div class="w3img-grids-info-gd position-relative">
                                <a href="#services">
                                    <div class="page">
                                        <div class="photobox photobox_triangular photobox_scale-rotated">
                                            <div class="photobox__previewbox media-placeholder">
                                                <img class="img-fluid photobox__preview media-placeholder__media radius-image" src="assets/images/g3.jpg" alt="">
                                            </div>
                                            <div class="photobox__info-wrapper">
                                                <div class="photobox__info"><span> Integration</span></div>
                                            </div>

                                        </div>
                                    </div>
                                </a>
                                <div class="w3img-grids-info-gd-content mt-4">
                                    <a href="#gridsimg" class="titile-img d-block">
                                        <h4 class="mb-2">
                                            Meeting.</h4>
                                    </a>
                                    <p class="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.Lorem ipsum viverra feugiat. </p>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//img-grids->
   
    <!--/video-section-->
    <section class="w3l-video" id="video">
        <div class="video-mid-w3 py-5">
            <div class="container py-md-5 py-3">
                <!--/row-1-->
                <div class="row">
                    <div class="col-lg-6 mt-lg-0 mb-5 align-self pe-lg-3">
                        <div class="title-content text-left">
                            <h6 class="title-subhny mb-2">Time to grow</h6>
                            <h3 class="title-w3l two">Make better ideas happen fast
                            </h3>
                        </div>
                        <p class="mt-md-4 mt-3">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam</p>
                        <div class="w3l-two-buttons">
                            <a href="about.php" class="btn btn-style btn-primary mt-lg-5 mt-4">Read More </a>
                            <a href="#view" class="btn btn-style btn-white mt-lg-5 mt-4 ms-2"> Contact Us</a>
                        </div>
                    </div>
                    <div class="col-lg-6 videow3-right ps-lg-5">
                        <div class="w3l-index5 py-5">
                            <div class="history-info align-self text-center py-5 my-lg-5">
                                <div class="position-relative py-5">
                                    <a href="#small-dialog1" class="popup-with-zoom-anim play-view text-center position-absolute">
                                        <span class="video-play-icon">
                                            <span class="fa fa-play"></span>
                                        </span>
                                    </a>
                                    <!-- dialog itself, mfp-hide class is required to make dialog hidden 
                                    <div id="small-dialog1" class="zoom-anim-dialog mfp-hide">
                                        <iframe src="https://player.vimeo.com/video/124801644" frameborder="0" allow="autoplay; fullscreen" allowfullscreen=""></iframe>
                                    </div>
									   dialog itself, mfp-hide class is required to make dialog hidden --> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--//row-1-->
            </div>
        </div>
    </section>
    <!--//video-section-->

    <!--/tabs-faqs-->
    <section class="w3l-products w3l-faq-block py-5" id="projects">
        <div class="container py-md-5 py-2">
            <div class="header-secw3 text-center mb-5">
                <h6 class="title-subhny mb-2">faqs</h6>
                <h3 class="title-w3l mb-4">Ask Your Questions

                </h3>
            </div>
            <div class="row">
                <div class="col-lg-6 mx-auto pe-lg-5">
                    <div class="w3hny-business-img">
                        <img src="assets/images/g8.jpg" alt="" class="img-fluid radius-image">
                    </div>

                </div>
                <div class="col-lg-6 mt-lg-0 mt-sm-5 mt-4">
                    <div class="accordion">
                        <div class="accordion-item">
                            <button id="accordion-button-1" aria-expanded="true"><span class="accordion-title">
                             How much does a new website cost?</span><span class="icon" aria-hidden="true"></span></button>
                            <div class="accordion-content">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Elementum sagittis vitae et leo duis
                                    ut. Ut tortor.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button id="accordion-button-2" aria-expanded="false"><span class="accordion-title">Will my website be mobile-friendly?</span><span class="icon" aria-hidden="true"></span></button>
                            <div class="accordion-content">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Elementum sagittis vitae et leo duis
                                    ut. Ut pretium.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button id="accordion-button-3" aria-expanded="false"><span class="accordion-title">How long does it take to build a website?</span><span class="icon" aria-hidden="true"></span></button>
                            <div class="accordion-content">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Elementum sagittis vitae et leo duis
                                    ut. Ut tortor.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button id="accordion-button-4" aria-expanded="false"><span class="accordion-title">Can I update the website myself once it’s built?</span><span class="icon" aria-hidden="true"></span></button>
                            <div class="accordion-content">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Elementum sagittis vitae et leo duis
                                    ut. Ut potenti.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//tabs-faqs-->

    <!-- testimonials -->
    <section class="w3l-clients" id="clients">
        <!-- /grids -->
        <div class="cusrtomer-layout py-5">
            <div class="container py-lg-5 py-md-3">
                <!-- /grids -->
                <div class="testimonial-width">
 
                        <div class="item">
                            <div class="testimonial-content">
                                <div class="testimonial">
                                    <blockquote>
                                        <i class="fas fa-quote-left"></i>
                                        <q> I have been very impressed with Digit Web Studio service and overall approach to giving us the client what they want, and doing it in such a way that we would never go anywhere else.</q>
                                    </blockquote>
                                    <div class="testi-des">

                                        <div class="peopl align-self">
                                            <h3>Avinash Mourya</h3>
                                            <p class="indentity">Nehru Place, New Delhi</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            <!-- /grids -->
        </div>
        <!-- //grids -->
    </section>
    <!-- //testimonials -->
    <!--/w3l-project-->
    <section class="w3l-project-main">
        <div class="container">
            <div class="w3l-project py-md-5 py-4">
                <div class="row py-5 align-items-center">
                    <div class="col-lg-6 w3l-project-right">
                        <div class="bottom-info">
                            <div class="header-section pr-lg-5">
                                <h6 class="title-subhny mb-2">Stay Update!</h6>
                                <h3 class="title-w3l">Subscribe to our newsletter
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 w3l-project-left">
                        <form action="#" method="post" class="subscribe-wthree mt-lg-5 mt-4">
                            <div class="flex-wrap subscribe-wthree-field">
                                <input class="form-control" type="email" placeholder="Your Email Address" name="email" required="">
                                <button class="btn btn-style btn-primary" type="submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//w3l-project-->
    <!-- footer -->
    <section class="w3l-footer-29-main">
        <div class="footer-29 py-5">
            <div class="container py-lg-4">
                <div class="row footer-top-29">
                    <div class="col-lg-4 col-md-6 footer-list-29 footer-1 pe-lg-5">
                        <div class="footer-logo mb-4">
                            <h2><a class="navbar-brand" href="index.php">
                                    <span class="sublog">Digit</span>Marketing
                                </a></h2>
                        </div>
                        <p>Lorem ipsum dolor sit, amet consectetur elit.Pellen tesque libero ut justo, ultrices in ligula accusantium libero fugit.

                        </p>
                        <div class="w3l-two-buttons mt-4">
                            <a href="#trail" class="btn btn-primary btn-style"> Try it For Free </a>
                        </div>
                        <div class="main-social-footer-29 mt-5">
                            <a href="#facebook" class="facebook"><span class="fab fa-facebook-f"></span></a>
                            <a href="#twitter" class="twitter"><span class="fab fa-twitter"></span></a>
                            <a href="#instagram" class="instagram"><span class="fab fa-instagram"></span></a>
                            <a href="#linkedin" class="linkedin"><span class="fab fa-linkedin-in"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-2 mt-sm-0 mt-5">

                        <ul>
                            <h6 class="footer-title-29">Links</h6>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="contact.php">Contact us</a></li>

                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-3 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Services</h6>
                        <ul>
                            <li><a href="#traning">Web Design</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#traning">Marketing Plans</a></li>
                            <li><a href="#marketplace">Digital Services</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#platform">Product Selling</a></li>
                        </ul>

                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">More Info</h6>
                        <ul>
                            <li><a href="#seo">Offline SEO</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#hack">Growth Hacking</a></li>
                            <li><a href="#studio">Film Studio</a></li>
                            <li><a href="#branding">Branding</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#marketplace">Lead Generation</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Support</h6>
                        <ul>
                            <li><a href="#awards">Awards</a></li>
                            <li><a href="#secutiry">Security</a></li>

                            <li><a href="#proj">Products</a></li>
                            <li><a href="#efaq">faQ</a></li>
                            <li><a href="#help">Help</a></li>
                            <li><a href="#mail">Mail Us</a></li>
                            <li><a href="#terms">Terms
                                </a></li>
                            <li><a href="#policy">Privacy Policy</a></li>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- copyright -->
        <section class="w3l-copyright text-center">
            <div class="container">
                <p class="copy-footer-29">© 2021 DigitMarketing. All rights reserved. Design by <a href="https://" target="_blank">
                        Digit Marketing</a></p>
            </div>

            <!-- move top -->
            <button onclick="topFunction()" id="movetop" title="Go to top">
                <span class="fas fa-arrow-up"></span>
            </button>
            <script>
                // When the user scrolls down 20px from the top of the document, show the button
                window.onscroll = function() {
                    scrollFunction()
                };

                function scrollFunction() {
                    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                        document.getElementById("movetop").style.display = "block";
                    } else {
                        document.getElementById("movetop").style.display = "none";
                    }
                }

                // When the user clicks on the button, scroll to the top of the document
                function topFunction() {
                    document.body.scrollTop = 0;
                    document.documentElement.scrollTop = 0;
                }

            </script>
            <!-- /move top -->
        </section>
        <!-- //copyright -->
    </section>
    <!-- //footer -->
    <!-- Js scripts -->
    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/theme-change.js"></script>
     <script src="assets/js/jquery-1.9.1.min.js"></script>
    <!-- faq -->
    <script>
        const items = document.querySelectorAll(".accordion button");

        function toggleAccordion() {
            const itemToggle = this.getAttribute('aria-expanded');

            for (i = 0; i < items.length; i++) {
                items[i].setAttribute('aria-expanded', 'false');
            }

            if (itemToggle == 'false') {
                this.setAttribute('aria-expanded', 'true');
            }
        }

        items.forEach(item => item.addEventListener('click', toggleAccordion));

    </script>
    <!-- //faq -->
    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- //bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
