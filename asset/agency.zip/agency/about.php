<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>DigitMarketing - Business Category Bootstrap Responsive Template | About :: W3layouts</title>
    <!--/google-fonts -->
    <link href="//fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,700;1,400;1,600&display=swap" rel="stylesheet">
    <!--//google-fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <!--/Header-->
    <header id="site-header" class="fixed-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a class="navbar-brand pe-xl-5 pe-lg-4" href="index.php">
                        <span class="sublog">Digit</span>Marketing
                    </a></h1>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav me-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About</a>
                        </li>
						<li class="nav-item">
                            <a class="nav-link" href="services.php">Services</a>
                        </li>
                     
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>

                    </ul>
                    <ul class="navbar-nav search-right mt-lg-0 mt-2">
                        <li class="nav-item" title="Search"><a href="#search" class="search-search">
                                <span class="fas fa-search" aria-hidden="true"></span></a></li>
                        <li class="nav-item me-lg-3"><a href="" class="phone-btn btn btn-primary btn-style d-none d-lg-block btn-style ms-2">Purchase</a></li>
                    </ul>

                    <!-- //toggle switch for light and dark theme -->

                    <!-- search popup -->
                    <div id="search" class="w3lpop-overlay">
                        <div class="w3lpopup">
                            <form action="#formsearch" method="GET" class="d-sm-flex">
                                <input class="form-control me-2" type="search" placeholder="Search here..." aria-label="Search" required="">
                                <button class="btn btn-style btn-primary" type="submit">Search</button>
                                <a class="close" href="#formsearch">&times;</a>
                            </form>
                        </div>
                    </div>
                    <!-- /search popup -->
                </div>
                <!-- toggle switch for light and dark theme -->
                <div class="mobile-position">
                    <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox">
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>
        </div>
    </header>
    <!--//Header-->
    <!-- breadcrumb -->
    <section class="w3l-about-breadcrumb">
        <div class="breadcrumb-bg breadcrumb-bg-about">
            <div class="container py-lg-5 py-sm-4">
                <div class="w3breadcrumb-gids text-center">
                    <div class="w3breadcrumb-info mt-5">
                        <h2 class="w3ltop-title pt-4">About Us</h2>
                        <ul class="breadcrumbs-custom-path">
                            <li><a href="index.php">Home</a></li>
                            <li class="active"><span class="fas fa-angle-double-right mx-2"></span> About </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//breadcrumb-->
    <!-- feature with photo1 -->
    <section class="w3l-feature-with-photo-1">
        <div class="feature-with-photo-hny py-5">
            <div class="container py-lg-5">
                <div class="feature-with-photo-content">
                    <div class="ab-in-flow row mb-lg-5 mb-3">

                        <div class="col-lg-7 ab-right pl-lg-5">
                            <h6 class="title-subhny mb-2"><span>About Us</span></h6>
                            <h3 class="title-w3l mb-4">We’ve skilled in wide range of web and other digital market tools & designs.

                            </h3>
                            <p class="mt-4">Excepteur sint occaecat non proident, sunt in culpa quis. Phasellus lacinia
                                id
                                erat eu ullamcorper. Nunc id ipsum fringilla,
                                gravida felis vitae. Phasellus lacinia id, sunt in culpa quis. Phasellus lacinia Excepteur sint occaecat
                                non proident, sunt in culpa quis.Nunc id ipsum fringilla.</p>

                            <div class="w3l-buttons mt-sm-5 mt-4">
                                <a class="btn btn-primary btn-style me-2" href="about.php">Read More </a>
                                <a class="btn btn-outline-primary btn-style mr-2" href="services.php">Services </a>
                            </div>
                        </div>
                        <div class="col-lg-5 ab-left ps-lg-5">
                            <img src="assets/images/ab1.jpg" class="img-fluid radius-image" alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- //feature with photo1 -->

    <!--/tabs-faqs-->
    <section class="w3l-products py-5" id="tabs">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="header-sec mx-auto text-center">
                <h6 class="title-subhny mb-2">We Provide</h6>
                <h3 class="title-w3l mb-5">Specialization in developing<br> business strategy
                </h3>
            </div>
            <div class="row">
                <div class="col-lg-12 mx-auto">

                    <!--Horizontal Tab-->
                    <div id="parentHorizontalTab">
                        <ul class="resp-tabs-list hor_1 mb-2">
                            <li>What we do</li>
                            <li>Our Mission</li>
                            <li>Social impact</li>
                            <li>Marketing</li>
                            <div class="clear"></div>
                        </ul>
                        <div class="resp-tabs-container hor_1">
                            <div class="products-content">
                                <div class="row mt-4">
                                    <div class="col-lg-6 tabw3-left">
                                        <h4 class="head">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                            incididunt ut labore et dolore </h4>
                                        <p>Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates.
                                            Minima velit expedita maiores, sit at in!</p>
                                        <ul class="w3l-right-book mt-4">
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>We offer wide range of skills</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>We help analyze,transform business models</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>consulting services include project management</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Manage your workflow and tasks successfully</li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 tabw3-right ps-lg-5 mt-lg-0 mt-5">
                                        <img src="assets/images/g9.jpg" class="img-fluid radius-image" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="products-content">
                                <div class="row mt-4">
                                    <div class="col-lg-6 tabw3-right">
                                        <img src="assets/images/g3.jpg" class="img-fluid radius-image" alt="">
                                    </div>
                                    <div class="col-lg-6 tabw3-left ps-lg-5 mt-lg-0 mt-5">
                                        <h4 class="head">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                            incididunt ut labore et dolore </h4>
                                        <p>Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates.
                                            Minima velit expedita maiores, sit at in!</p>
                                        <ul class="w3l-right-book mt-4">
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                            <div class="products-content">
                                <div class="row mt-4">

                                    <div class="col-lg-6 tabw3-left">
                                        <h4 class="head">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                            incididunt ut labore et dolore </h4>
                                        <p>Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates.
                                            Minima velit expedita maiores, sit at in!</p>
                                        <ul class="w3l-right-book mt-4">
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>We offer wide range of skills</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>We help analyze,transform business models</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>consulting services include project management</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Manage your workflow and tasks successfully</li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-6 tabw3-right ps-lg-5 mt-lg-0 mt-5">
                                        <img src="assets/images/g8.jpg" class="img-fluid radius-image" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="products-content">
                                <div class="row mt-4">
                                    <div class="col-lg-6 tabw3-right">
                                        <img src="assets/images/g7.jpg" class="img-fluid radius-image" alt="">
                                    </div>
                                    <div class="col-lg-6 tabw3-left ps-lg-5 mt-lg-0 mt-5">
                                        <h4 class="head">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                            incididunt ut labore et dolore </h4>
                                        <p>Lorem ipsum dolor sit amet, elit. Id ab commodi impedit magnam sint voluptates.
                                            Minima velit expedita maiores, sit at in!</p>
                                        <ul class="w3l-right-book mt-4">
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Always Fast and friendly support</li>
                                            <li><span class="fa fa-check" aria-hidden="true"></span>Experienced Professional Team</li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//tabs-faqs-->
    <!--/progress-->
    <section class="w3l-servicesblock w3l-servicesblock1 py-5" id="progress">
        <div class="container py-lg-5 py-md-4 py-2">
            <div class="row">
                <div class="col-lg-6 mb-lg-0 mb-5 pe-lg-5">
                    <h6 class="title-subhny mb-2">Progress Bars</h6>

                    <h3 class="title-w3l">The growth accelerator for startups</h3>
                    <p class="mt-md-4 mt-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                        ultrices in ligula. Semper at. Lorem ipsum dolor sit amet
                        elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit amet. Lorem ipsum init
                        dolor sit, amet elit. Dolor ipsum non velit, culpa! elit ut et.</p>

                </div>
                <div class="col-lg-6 align-self pe-lg-4">
                    <div class="progress-info info1">
                        <h6 class="progress-tittle">Design <span class="">66%</span></h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width:66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info info1">
                        <h6 class="progress-tittle">Development <span class="">70%</span></h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width:70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info info2">
                        <h6 class="progress-tittle">PHP <span class="">80%</span>
                        </h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width:80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>
                    <div class="progress-info info3">
                        <h6 class="progress-tittle">Art Direction <span class="">90%</span></h6>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </section>
    <!--//progress-->
    <!--/w3l-project-->
    <!--/team-sec-->
    <div class="w3l-team-main py-5" id="team">
        <div class="container py-md-5 py-3">
            <div class="header-secw3 text-center">
                <div class="header-secw3 text-center">
                    <h6 class="title-subhny mb-2">Our Team</h6>
                    <h3 class="title-w3l mb-3">
                        Creative Team
                    </h3>
                </div>

            </div>
            <div class="row w3ls_team_grids text-center">
                <div class="col-md-3 col-6 w3_agile_team_grid mt-md-5 mt-4">
                    <div class="box4">
                        <a href="#"> <img src="assets/images/team1.jpg" alt=" " class="img-fluid radius-image"></a>
                        <div class="box-content">
                            <h3 class="title">Web Developer</h3>
                            <ul class="icon">
                                <li><a href="#" class="fab fa-facebook-f"></a></li>
                                <li><a href="#" class="fab fa-instagram"></a></li>
                            </ul>
                        </div>
                    </div>

                    <h4><a href="#url" class="title-head">
                            Glendell Paul</a></h4>
                    <p>Lorem ipsum</p>
                </div>
                <div class="col-md-3 col-6 w3_agile_team_grid mt-md-5 mt-4">
                    <div class="box4">
                        <a href="#"> <img src="assets/images/team2.jpg" alt=" " class="img-fluid radius-image"></a>
                        <div class="box-content">
                            <h3 class="title">Editor</h3>
                            <ul class="icon">
                                <li><a href="#" class="fab fa-facebook-f"></a></li>
                                <li><a href="#" class="fab fa-instagram"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4><a href="#url" class="title-head">
                            Dania Ruthor</a></h4>
                    <p>Lorem ipsum</p>
                </div>
                <div class="col-md-3 col-6 w3_agile_team_grid mt-md-5 mt-4">
                    <div class="box4">
                        <a href="#"> <img src="assets/images/team3.jpg" alt=" " class="img-fluid radius-image"></a>
                        <div class="box-content">
                            <h3 class="title">UX Designer</h3>
                            <ul class="icon">
                                <li><a href="#" class="fab fa-facebook-f"></a></li>
                                <li><a href="#" class="fab fa-instagram"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4><a href="#url" class="title-head">
                            Gambria Rich</a></h4>
                    <p>Lorem ipsum</p>
                </div>
                <div class="col-md-3 col-6 w3_agile_team_grid mt-md-5 mt-4">
                    <div class="box4">
                        <a href="#"> <img src="assets/images/team4.jpg" alt=" " class="img-fluid radius-image"></a>
                        <div class="box-content">
                            <h3 class="title">Web Designer</h3>
                            <ul class="icon">
                                <li><a href="#" class="fab fa-facebook-f"></a></li>
                                <li><a href="#" class="fab fa-instagram"></a></li>
                            </ul>
                        </div>
                    </div>
                    <h4><a href="#url" class="title-head">
                            Laura Carl</a></h4>
                    <p>Lorem ipsum</p>
                </div>

            </div>
        </div>
    </div>
    <!--//team-sec-->
    <!--/w3l-project-->
    <section class="w3l-project-main">
        <div class="container">
            <div class="w3l-project py-md-5 py-4">
                <div class="row py-5 align-items-center">
                    <div class="col-lg-8 w3l-project-right">
                        <div class="bottom-info">
                            <div class="header-section pr-lg-5">
                                <h6 class="title-subhny mb-2">Consultation</h6>
                                <h3 class="title-w3l">Request Free Consultation <br>Lets Do It!
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 w3l-project-left about-w3page-btns mt-lg-0 mt-4">
                        <div class="w3l-buttons d-sm-flex">
                            <a class="btn btn-primary btn-style me-2" href="about.php">Read More </a>
                            <a class="btn btn-outline-primary btn-style" href="contact.php">Contact Us </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--//w3l-project-->
    <!-- footer -->
    <section class="w3l-footer-29-main">
        <div class="footer-29 py-5">
            <div class="container py-lg-4">
                <div class="row footer-top-29">
                    <div class="col-lg-4 col-md-6 footer-list-29 footer-1 pe-lg-5">
                        <div class="footer-logo mb-4">
                            <h2><a class="navbar-brand" href="index.php">
                                    <span class="sublog">Digit</span>Marketing
                                </a></h2>
                        </div>
                        <p>Lorem ipsum dolor sit, amet consectetur elit.Pellen tesque libero ut justo, ultrices in ligula accusantium libero fugit.

                        </p>
                        <div class="w3l-two-buttons mt-4">
                            <a href="#trail" class="btn btn-primary btn-style"> Try it For Free </a>
                        </div>
                        <div class="main-social-footer-29 mt-5">
                            <a href="#facebook" class="facebook"><span class="fab fa-facebook-f"></span></a>
                            <a href="#twitter" class="twitter"><span class="fab fa-twitter"></span></a>
                            <a href="#instagram" class="instagram"><span class="fab fa-instagram"></span></a>
                            <a href="#linkedin" class="linkedin"><span class="fab fa-linkedin-in"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-2 mt-sm-0 mt-5">

                        <ul>
                            <h6 class="footer-title-29">Links</h6>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="blog.php"> Blog posts</a></li>
                            <li><a href="contact.php">Contact us</a></li>

                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-list-29 footer-3 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Services</h6>
                        <ul>
                            <li><a href="#traning">Web Design</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#traning">Marketing Plans</a></li>
                            <li><a href="#marketplace">Digital Services</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#platform">Product Selling</a></li>
                        </ul>

                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">More Info</h6>
                        <ul>
                            <li><a href="#seo">Offline SEO</a></li>
                            <li><a href="#traning">Development</a></li>
                            <li><a href="#hack">Growth Hacking</a></li>
                            <li><a href="#studio">Film Studio</a></li>
                            <li><a href="#branding">Branding</a></li>
                            <li><a href="#experts">Email Marketing</a></li>
                            <li><a href="#marketplace">Lead Generation</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-6  footer-list-29 footer-4 mt-lg-0 mt-5">
                        <h6 class="footer-title-29">Support</h6>
                        <ul>
                            <li><a href="#awards">Awards</a></li>
                            <li><a href="#secutiry">Security</a></li>

                            <li><a href="#proj">Products</a></li>
                            <li><a href="#efaq">faQ</a></li>
                            <li><a href="#help">Help</a></li>
                            <li><a href="#mail">Mail Us</a></li>
                            <li><a href="#terms">Terms
                                </a></li>
                            <li><a href="#policy">Privacy Policy</a></li>


                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- copyright -->
        <section class="w3l-copyright text-center">
            <div class="container">
                <p class="copy-footer-29">© 2021 DigitMarketing. All rights reserved. Design by <a href="https://w3layouts.com/" target="_blank">
                        W3Layouts</a></p>
            </div>

            <!-- move top -->
            <button onclick="topFunction()" id="movetop" title="Go to top">
                <span class="fas fa-arrow-up"></span>
            </button>
            <script>
                // When the user scrolls down 20px from the top of the document, show the button
                window.onscroll = function() {
                    scrollFunction()
                };

                function scrollFunction() {
                    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                        document.getElementById("movetop").style.display = "block";
                    } else {
                        document.getElementById("movetop").style.display = "none";
                    }
                }

                // When the user clicks on the button, scroll to the top of the document
                function topFunction() {
                    document.body.scrollTop = 0;
                    document.documentElement.scrollTop = 0;
                }

            </script>
            <!-- /move top -->
        </section>
        <!-- //copyright -->
    </section>
    <!-- //footer -->
    <!-- Js scripts -->
    <!-- Template JavaScript -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/theme-change.js"></script>
    <!--/Tabs-->
    <script src="assets/js/jquery-1.9.1.min.js"></script>
    <script src="assets/js/easyResponsiveTabs.js"></script>
    <!--Plug-in Initialisation-->
    <script type="text/javascript">
        $(document).ready(function() {
            //Horizontal Tab
            $('#parentHorizontalTab').easyResponsiveTabs({
                type: 'default', //Types: default, vertical, accordion
                width: 'auto', //auto or any width like 600px
                fit: true, // 100% fit in a container
                tabidentify: 'hor_1', // The tab groups identifier
                activate: function(event) { // Callback function if tab is switched
                    var $tab = $(this);
                    var $info = $('#nested-tabInfo');
                    var $name = $('span', $info);
                    $name.text($tab.text());
                    $info.show();
                }
            });
        });

    </script>
    <!--//Tabs-->
    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function() {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function() {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function() {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });

    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function() {
            $('.navbar-toggler').click(function() {
                $('body').toggleClass('noscroll');
            })
        });

    </script>
    <!-- //disable body scroll which navbar is in active -->

    <!-- //bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
